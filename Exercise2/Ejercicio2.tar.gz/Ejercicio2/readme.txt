Analiza los programas OpenMP que encuentras en el directorio. Compila con la opci�n -fopenmp y var�a el n�mero de hilos donde sea necesario.

Debes seguir el siguiente orden de ejecucion: holaomp.c, paraomp.c,  foromp.c, cpiomp.c, paraforomp.c, sectionomp.c

